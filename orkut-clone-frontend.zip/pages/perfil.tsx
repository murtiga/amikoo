export default function Perfil() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Bem-vindo ao seu perfil!</h1>
      <p>Conteúdo da rede social aqui...</p>
    </div>
  );
}
